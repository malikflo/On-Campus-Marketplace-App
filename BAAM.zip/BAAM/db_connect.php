<?php 
// connect to my sql
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jakjdb";	// Database name
$tblname1="employee"; // Table name
//$tblname2="inventory"; // Table name
//$tblname3="members"; // Table name
//$tblname4="orders"; // Table name
// Connect to server and select databse.	
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} else {
	// echo "Successfully Connected";
}
?>
