/********************
Name:  Alvin Tyson
Initial Database Tables
*********************/

/*** Terminal login command ***/
mysql -u root -p


/*** Create DB ***/
DROP DATABASE IF EXISTS baamdb;
CREATE DATABASE baamdb;

/*** Select DB ***/
USE baamdb;

/*** Create Tables ***/
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  usernm	VARCHAR(20),
  userpw	VARCHAR(20), 
  fname		VARCHAR(20) not null, 
  lname		VARCHAR(20) not null,
  email		VARCHAR(30), 
  phone		BIGINT, 
  userid	integer(4),
  primary key (userid),
  unique (usernm)
);

DROP TABLE IF EXISTS items;
CREATE TABLE items (
  userid	integer(4) not null,
  itemid	integer(4) not null, 
  itemType	VARCHAR(20) not null,
  itemDesc	VARCHAR(30) not null,
  itemCost	integer(4) not null,
  itemPic   varbinary(65535) not null,
  primary key (itemType),
  unique (userid, itemid)
);

/*** 
-- Dump Database Configuration Information
SHOW DATABASES;
SHOW TABLES;
DESC users;
DESC items;
***/ 


